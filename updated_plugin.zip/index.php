<?php

if ( !defined('ABSPATH') )
    die ( 'No direct script access allowed' );



?>

