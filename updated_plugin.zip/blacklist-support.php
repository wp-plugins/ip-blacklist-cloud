<?php

if ( !defined('ABSPATH') )
    die ( 'No direct script access allowed' );



?>


<?php





//---start admin options

	?>

<div class="wrap">

<div id="icon-options-general" class="icon32"><br /></div>  

<?php

global $wpdb;




?>



<BR>

<h2> Support</h2>
<BR>

If you are facing any problem, you can contact me at <b>contact@adiie9.com</b> or <b>ad33l@live.com</b><BR>
<BR>

<form action="https://www.paypal.com/cgi-bin/webscr" method="post" target="_top">
<input type="hidden" name="cmd" value="_s-xclick">
<input type="hidden" name="hosted_button_id" value="7LME7BBHK7XWS">
<input type="image" src="https://www.paypalobjects.com/en_US/i/btn/btn_donateCC_LG.gif" border="0" name="submit" alt="PayPal - The safer, easier way to pay online!">
<img alt="" border="0" src="https://www.paypalobjects.com/en_US/i/scr/pixel.gif" width="1" height="1">
</form>



</div>
